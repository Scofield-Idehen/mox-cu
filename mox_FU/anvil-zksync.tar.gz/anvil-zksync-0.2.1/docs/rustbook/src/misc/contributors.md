# Contributors

Here is a list of the contributors who have helped improving mdBook. Big shout-out to them!

* [nbaztec](https://github.com/nbaztec)