# Example override directory

This directory is an example on how to use the `override-bytecodes-dir` flag.

You put your bytecodes in this directory, under a proper file name - that should match the address that you're overriding, and run
the anvil-zksync with `--override-bytecodes-dir=example_override` flag.